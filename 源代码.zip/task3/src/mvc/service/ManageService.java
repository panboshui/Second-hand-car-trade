package mvc.service;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;



import mvc.util.JdbcTools;
import mvc.bean.manage;
import mvc.bean.vip;
import mvc.dao.ManageDao;
import mvc.dao.VipDao;
import mvc.daoImpl.ManageDaoJdbcImpl;
import mvc.daoImpl.VipDaoJdbcImpl;


public class ManageService {
      private ManageDao dao;
      
      public ManageService() {
    	  this.dao=new ManageDaoJdbcImpl();
      }
      
      public manage SearchManageByName(manage conditions) {
    	  Connection connection=null;
    	 manage realpass=new manage();
    	  try {
    		  connection=JdbcTools.getConnection();
    		  realpass=dao.searchManageByName(connection, conditions);
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return realpass;
      }
      
      public boolean searchName(String name) {
    	  boolean result=false;
    	  Connection connection=null;
    	  manage user=new manage();
    	  try {
    		  connection=JdbcTools.getConnection();
    		 user=dao.searchName(connection, name);
    		 if(user.getName()!=null)
    			 result=true;
    		 
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return result;
      }
      
  
      
     
}
