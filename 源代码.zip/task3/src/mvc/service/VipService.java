package mvc.service;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;



import mvc.util.JdbcTools;
import mvc.bean.salemessage;
import mvc.bean.vip;
import mvc.dao.VipDao;
import mvc.daoImpl.VipDaoJdbcImpl;


public class VipService {
      private VipDao dao;
      
      public VipService() {
    	  this.dao=new VipDaoJdbcImpl();
      }
      
      public vip SearchVipByName(vip conditions) {
    	  Connection connection=null;
    	 vip realpass=new vip();
    	  try {
    		  connection=JdbcTools.getConnection();
    		  realpass=dao.searchVipByName(connection, conditions);
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return realpass;
      }
      
      public vip getVip(int id) {
    	  vip member=new vip();
    	  Connection connection=null;
    	  try {
    		  connection=JdbcTools.getConnection();
    		  member=dao.searchVipById(connection, id);
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return member;
      }
      public  List<vip> searchAllVip() {
    	  List<vip> member=new ArrayList<vip>();
    	  Connection connection=null;
    	  try {
    		  connection=JdbcTools.getConnection();
    		  member=dao.searchAllVip(connection);
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return member;
      }
    

      
      public boolean addVip(vip member) {
    	  boolean result=false;
    	  Connection connection=null;
    	  
    	  try {
    		  connection=JdbcTools.getConnection();
    		 dao.addVip(connection, member);
    		 result=true;
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return result;
      }
      
      public boolean updateVip(vip member) {
    	  Connection connection=null;
    	  boolean result=false;
    	  try {
    		  connection=JdbcTools.getConnection();
    		  dao.updateVip(connection, member);
    		  result=true;
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return result;
      }
      
      public boolean searchName(String name) {
    	  boolean result=false;
    	  Connection connection=null;
    	  vip user=new vip();
    	  try {
    		  connection=JdbcTools.getConnection();
    		 user=dao.searchName(connection, name);
    		 if(user.getName()!=null)
    			 result=true;
    		 
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return result;
      }
      
      public void deleteVip(Integer member) {
    	  Connection connection=null;
    	  
    	  try {
    		  connection=JdbcTools.getConnection();
    		  dao.deleteVip(connection, member);
    	
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	
      }
      
     
}
