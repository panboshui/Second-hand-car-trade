package mvc.service;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;


import mvc.util.JdbcTools;
import mvc.bean.liuyan;
import mvc.bean.salemessage;
import mvc.bean.salemessageSearch;
import mvc.dao.LiuyanDao;
import mvc.dao.SalemessageDao;
import mvc.daoImpl.LiuyanDaoJdbcImpl;
import mvc.daoImpl.SalemessageDaoJdbcImpl;
 

public class LiuyanService {
      private LiuyanDao dao;
      
      public LiuyanService() {
    	  this.dao=new LiuyanDaoJdbcImpl();
      }
      
     
      public List<liuyan> searchLiuyan(Integer id) {
    	  Connection connection=null;
    	  List<liuyan> members=new ArrayList<liuyan>();
    	  try {
    		  connection=JdbcTools.getConnection();
    		  members=dao.searchliuyan(connection, id);
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return members;
      }
      
      public void inputLiuyan(liuyan member) {
       	  Connection connection=null;
    	  try {
    		  connection=JdbcTools.getConnection();
    		 dao.addLiuyan(connection, member);
    		 
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	
      }
      
  
     
}
