package mvc.service;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;


import mvc.util.JdbcTools;
import mvc.bean.salemessage;
import mvc.bean.salemessageSearch;
import mvc.dao.SalemessageDao;
import mvc.daoImpl.SalemessageDaoJdbcImpl;
 

public class SalemessageService {
      private SalemessageDao dao;
      
      public SalemessageService() {
    	  this.dao=new SalemessageDaoJdbcImpl();
      }
      
      public salemessage searchSalemessageByContent(String content) {
    	  Connection connection=null;
    	  salemessage realpass=new salemessage();
    	  try {
    		  connection=JdbcTools.getConnection();
    		  realpass=dao.searchSalemessageByContent(connection, content);
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return realpass;
      }
      
  
    
      public salemessage getMessage(Integer id) {
    	  salemessage member=new salemessage();
    	  Connection connection=null;
    	  try {
    		  connection=JdbcTools.getConnection();
    		  member=dao.searchSalemessageById(connection, id);
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return member;
      }
      
      public void addsalemessage(salemessage member) {
       	  Connection connection=null;
    	  try {
    		  connection=JdbcTools.getConnection();
    		 dao.addSalemessage(connection, member);
    		 
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	
      }
      
      public void updateSalemessage(salemessage member) {
    	  Connection connection=null;
    	  
    	  try {
    		  connection=JdbcTools.getConnection();
    		  dao.updateSalemessage(connection, member);
    	
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	
      }
      public void publishSalemessage(salemessage member) {
    	  Connection connection=null;
    	  
    	  try {
    		  connection=JdbcTools.getConnection();
    		  dao.publishSalemessage(connection, member);
    	
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	
      }
      public void agreeToPublish(Integer id) {
    	  Connection connection=null;
    	  
    	  try {
    		  connection=JdbcTools.getConnection();
    		  dao.agreetopublish(connection, id);
    	
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	
      }
      public void changeMessageflag(salemessage member) {
    	  Connection connection=null;
    	  
    	  try {
    		  connection=JdbcTools.getConnection();
    		  dao.changemessageflag(connection, member);
    	
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	
      }
      public void deleteMessage(salemessage member) {
    	  Connection connection=null;
    	  
    	  try {
    		  connection=JdbcTools.getConnection();
    		  dao.deletemessage(connection, member);
    	
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	
      }
      public List<salemessage> searchMySalemessage(Integer id) {
    	  Connection connection=null;
    	  List<salemessage> members=new ArrayList<salemessage>();
    	  try {
    		  connection=JdbcTools.getConnection();
    		  members=dao.searchSaleMessageByUserid(connection, id);
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return members;
      }
      public List<salemessage> searchCommitSalemessage() {
    	  Connection connection=null;
    	  List<salemessage> members=new ArrayList<salemessage>();
    	  try {
    		  connection=JdbcTools.getConnection();
    		  members=dao.searchCommitSaleMessage(connection);
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return members;
      }
      public List<salemessage> searchAllSalemessage() {
    	  Connection connection=null;
    	  List<salemessage> members=new ArrayList<salemessage>();
    	  try {
    		  connection=JdbcTools.getConnection();
    		  members=dao.searchAllSaleMessage(connection);
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return members;
      }
      
      public List<salemessage> searchMySalemessageByConditions(salemessageSearch conditions) {
    	  Connection connection=null;
    	  List<salemessage> members=new ArrayList<salemessage>();
    	  try {
    		  connection=JdbcTools.getConnection();
    		  members=dao.searchMySalemessageByCondition(connection, conditions);
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return members;
      }
      
      public List<salemessage> searchAllSalemessageByConditions(salemessageSearch conditions) {
    	  Connection connection=null;
    	  List<salemessage> members=new ArrayList<salemessage>();
    	  try {
    		  connection=JdbcTools.getConnection();
    		  members=dao.searchAllSaleMessageByCondition(connection,conditions);
    	  }catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  JdbcTools.releaseResource(null, connection);
    	  }
    	  return members;
      }
     
}
