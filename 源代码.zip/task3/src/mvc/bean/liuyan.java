package mvc.bean;

public class liuyan {
	 
	 private Integer id;
	 private String content;

	 private Integer messageid;
	@Override
	public String toString() {
		return "liuyan [id=" + id + ", content=" + content + ", messageid=" + messageid + "]";
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	public Integer getMessageid() {
		return messageid;
	}
	public void setMessageid(Integer messageid) {
		this.messageid = messageid;
	}
	public liuyan(Integer id, String content, Integer messageid) {
		super();
		this.id = id;
		this.content = content;
		this.messageid = messageid;
	}
	public liuyan() {
		
	}
	 
	 
}
