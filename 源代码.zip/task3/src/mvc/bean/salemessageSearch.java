package mvc.bean;

public class salemessageSearch {
	 private String content;
	 private Integer id;
	public salemessageSearch() {
		super();
		
	}
	
	public salemessageSearch(String content,Integer id) {
		super();
		this.content = content;
		this.id=id;
	}

	public String getContent() {
		if(content==null || content.trim().equals(""))
			return "%%";
		else
			return "%"+content+"%";	
	}
	
	public void setContent(String content) {
		this.content = content;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id=id;
	}

	  
}
