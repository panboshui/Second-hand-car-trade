package mvc.bean;

public class salemessage {
	  private Integer id;
	  private String content;
	  private Integer userid;
	  private String publishflag;
	  private String messageflag;
	  private String commitflag;
	@Override
	public String toString() {
		return "salemessage [id=" + id + ", content=" + content + ", userid=" + userid + ", publishflag=" + publishflag
				+ ", messageflag=" + messageflag + ", commitflag=" + commitflag + "]";
	}
	public salemessage(Integer id, String content, Integer userid ,String publishflag, String messageflag,
			String commitflag) {
		super();
		this.id = id;
		this.content = content;
		this.userid = userid;
		this.publishflag = publishflag;
		this.messageflag = messageflag;
		this.commitflag = commitflag;
	}
	public salemessage() {
	
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public String getPublishflag() {
		return publishflag;
	}
	public void setPublishflag(String publishflag) {
		this.publishflag = publishflag;
	}
	public String getMessageflag() {
		return messageflag;
	}
	public void setMessageflag(String messageflag) {
		this.messageflag = messageflag;
	}
	public String getCommitflag() {
		return commitflag;
	}
	public void setCommitflag(String commitflag) {
		this.commitflag = commitflag;
	}
	  
}
