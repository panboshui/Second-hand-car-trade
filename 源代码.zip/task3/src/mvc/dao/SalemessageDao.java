package mvc.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import mvc.bean.salemessage;
import mvc.bean.salemessageSearch;


public interface SalemessageDao {

	public void addSalemessage(Connection connection,salemessage member)
	        throws SQLException;
	
	public salemessage searchSalemessageByContent(Connection connection,String content)
			throws SQLException;
	
	public salemessage searchSalemessageById(Connection connection,Integer id)
			throws SQLException;
	
	public void updateSalemessage(Connection connection,salemessage member)
			throws SQLException;
	
	public void publishSalemessage(Connection connection,salemessage member)
			throws SQLException;
	
	public void changemessageflag(Connection connection,salemessage member)
			throws SQLException;
	
	public void deletemessage(Connection connection,salemessage member)
			throws SQLException;
	public List<salemessage> searchSaleMessageByUserid(Connection connection, Integer userid)
			throws SQLException;
	
	public List<salemessage> searchAllSaleMessage(Connection connection)
			throws SQLException;
	public List<salemessage> searchMySalemessageByCondition(Connection connection,salemessageSearch member)
			throws SQLException;
	public List<salemessage> searchAllSaleMessageByCondition(Connection connection,salemessageSearch member)
			throws SQLException;
	public List<salemessage> searchCommitSaleMessage(Connection connection)
			throws SQLException;
	public void agreetopublish(Connection connection,Integer id)
			throws SQLException;
}
