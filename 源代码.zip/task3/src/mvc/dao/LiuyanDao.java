package mvc.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import mvc.bean.liuyan;
import mvc.bean.salemessage;
import mvc.bean.salemessageSearch;


public interface LiuyanDao {
	
	
	public List<liuyan> searchliuyan(Connection connection,Integer id)
			throws SQLException;
	public void addLiuyan(Connection connection,liuyan member)
			throws SQLException;
}
