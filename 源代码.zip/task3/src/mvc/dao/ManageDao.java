package mvc.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import mvc.bean.manage;
import mvc.bean.vip;

public interface ManageDao {

	
	
	public manage searchManageByName(Connection connection,manage conditions)
			throws SQLException;
	
	public manage searchName(Connection connection,String name)
			throws SQLException;
	
	
	

}
