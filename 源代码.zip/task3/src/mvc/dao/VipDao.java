package mvc.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import mvc.bean.salemessage;
import mvc.bean.vip;

public interface VipDao {

	public void addVip(Connection connection,vip member)
	        throws SQLException;
	
	public vip searchVipByName(Connection connection,vip conditions)
			throws SQLException;
	
	public vip searchName(Connection connection,String name)
			throws SQLException;
	
	public vip searchVipById(Connection connection,int id)
			throws SQLException;
	
	public void updateVip(Connection connection,vip member)
			throws SQLException;
	public List<vip> searchAllVip(Connection connection)
			throws SQLException;
	public void deleteVip(Connection connection,Integer id)
			throws SQLException;

}
