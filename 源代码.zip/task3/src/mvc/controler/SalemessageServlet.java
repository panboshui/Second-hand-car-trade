 package mvc.controler;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import mvc.bean.salemessage;
import mvc.bean.salemessageSearch;
import mvc.bean.vip;
import mvc.service.SalemessageService;




public class SalemessageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private SalemessageService service;
   
    public SalemessageServlet() {
        super();
        this.service=new SalemessageService();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String servletPath=request.getServletPath();
        System.out.println(servletPath);
        String methodName=servletPath.substring(1, servletPath.length()-3);
        System.out.println(methodName);
        try {
			Method method=getClass().getDeclaredMethod(methodName, HttpServletRequest.class,
					HttpServletResponse.class);
			method.invoke(this, request,response);
		} catch (Exception e) {
			
			e.printStackTrace();
		} 
				
	}
	
	public void listMySalemessage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
	
		int userid=Integer.parseInt(request.getParameter("id"));
		List<salemessage> member=service.searchMySalemessage(userid);
		vip user=new vip(userid,null,null,null,null);
		
		request.setAttribute("mysalemessage", member);
		request.setAttribute("user", user);
		List<salemessage> allmember=service.searchAllSalemessage();
		request.setAttribute("allsalemessage", allmember);
		
		request.getRequestDispatcher("/WEB-INF/views/salemessage/salemessage.jsp").forward(request, response);
	    
	}
	public void managelistSalemessage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		
		
		List<salemessage> allmember=service.searchAllSalemessage();
		request.setAttribute("allsalemessage", allmember);
		
		request.getRequestDispatcher("/WEB-INF/views/manage/allsalemessage.jsp").forward(request, response);
	    
	}
	public void listCommitSalemessage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		
		
		List<salemessage> member=service.searchCommitSalemessage();
		request.setAttribute("salemessages", member);
		request.getRequestDispatcher("/WEB-INF/views/manage/salemessagelist.jsp").forward(request, response);
	    
	}
    public void agreeToPublish(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
    	int id=Integer.parseInt(request.getParameter("id"));
		
		service.agreeToPublish(id);
		List<salemessage> member=service.searchCommitSalemessage();
		request.setAttribute("salemessages", member);
		request.getRequestDispatcher("/WEB-INF/views/manage/salemessagelist.jsp").forward(request, response);
	    
	}
	public void inputMessage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		
		int userid=Integer.parseInt(request.getParameter("userid"));
		String content=request.getParameter("content");
		salemessage member=new salemessage(null,content,userid,null,null,null);
	    service.addsalemessage(member);
	    
	    vip user=new vip(userid,null,null,null,null);
	    request.setAttribute("user", user);
	    List<salemessage> members=service.searchMySalemessage(userid);
		request.setAttribute("mysalemessage", members);
		
		List<salemessage> allmember=service.searchAllSalemessage();
		request.setAttribute("allsalemessage", allmember);
		
		request.getRequestDispatcher("/WEB-INF/views/salemessage/salemessage.jsp").forward(request, response);
	    
	}

	public void editMessage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		salemessage member=service.getMessage(id);
		request.setAttribute("message", member);
		request.getRequestDispatcher("/WEB-INF/views/salemessage/messageUpdate.jsp").forward(request, response);
		
	}
	public void updateMessage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		int userid=Integer.parseInt(request.getParameter("userid"));
		String content=request.getParameter("content");
	
		salemessage member=new salemessage(id,content,null,null,null,null);
		service.updateSalemessage(member);
		
		    vip user=new vip(userid,null,null,null,null);
		    request.setAttribute("user", user);
		    List<salemessage> members=service.searchMySalemessage(userid);
			request.setAttribute("mysalemessage", members);
			
			List<salemessage> allmember=service.searchAllSalemessage();
			request.setAttribute("allsalemessage", allmember);
		request.getRequestDispatcher("/WEB-INF/views/salemessage/salemessage.jsp").forward(request, response);
	}
	
	public void publishMessage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		salemessage member=service.getMessage(id);
		
		service.publishSalemessage(member);
		
		int userid=member.getUserid();
		    vip user=new vip(userid,null,null,null,null);
		    request.setAttribute("user", user);
		    List<salemessage> members=service.searchMySalemessage(userid);
			request.setAttribute("mysalemessage", members);
			
			List<salemessage> allmember=service.searchAllSalemessage();
			request.setAttribute("allsalemessage", allmember);
		request.getRequestDispatcher("/WEB-INF/views/salemessage/salemessage.jsp").forward(request, response);
	}
	
	public void changeMessageflag(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		salemessage member=service.getMessage(id);
		
		
		service.changeMessageflag(member);
		
		int userid=member.getUserid();
		    vip user=new vip(userid,null,null,null,null);
		    request.setAttribute("user", user);
		    List<salemessage> members=service.searchMySalemessage(userid);
			request.setAttribute("mysalemessage", members);
			
			List<salemessage> allmember=service.searchAllSalemessage();
			request.setAttribute("allsalemessage", allmember);
		request.getRequestDispatcher("/WEB-INF/views/salemessage/salemessage.jsp").forward(request, response);
	}
	public void deleteMessage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		salemessage member=service.getMessage(id);
		
		
		service.deleteMessage(member);
		
		int userid=member.getUserid();
		    vip user=new vip(userid,null,null,null,null);
		    request.setAttribute("user", user);
		    List<salemessage> members=service.searchMySalemessage(userid);
			request.setAttribute("mysalemessage", members);
			
			List<salemessage> allmember=service.searchAllSalemessage();
			request.setAttribute("allsalemessage", allmember);
		request.getRequestDispatcher("/WEB-INF/views/salemessage/salemessage.jsp").forward(request, response);
	}
	
	public void managedeleteMessage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		salemessage member=service.getMessage(id);
		
		
		service.deleteMessage(member);
		List<salemessage> allmember=service.searchAllSalemessage();
		request.setAttribute("allsalemessage", allmember);
		
		request.getRequestDispatcher("/WEB-INF/views/manage/allsalemessage.jsp").forward(request, response);
	}
	public void returnPage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		
		
		int userid=id;
		    vip user=new vip(userid,null,null,null,null);
		    request.setAttribute("user", user);
		    List<salemessage> members=service.searchMySalemessage(userid);
			request.setAttribute("mysalemessage", members);
			
			List<salemessage> allmember=service.searchAllSalemessage();
			request.setAttribute("allsalemessage", allmember);
		request.getRequestDispatcher("/WEB-INF/views/salemessage/salemessage.jsp").forward(request, response);
	}
	public void searchMyMessage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		String content=request.getParameter("content");
		salemessageSearch conditions=new salemessageSearch(content,id);
		int userid=id;
		    vip user=new vip(userid,null,null,null,null);
		    request.setAttribute("user", user);
		    List<salemessage> members=service.searchMySalemessageByConditions(conditions);
			request.setAttribute("mysalemessage", members);
			
			List<salemessage> allmember=service.searchAllSalemessage();
			request.setAttribute("allsalemessage", allmember);
		request.getRequestDispatcher("/WEB-INF/views/salemessage/salemessage.jsp").forward(request, response);
	}
	public void searchAllMessage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		String content=request.getParameter("content");
		salemessageSearch conditions=new salemessageSearch(content,null);
		int userid=id;
		    vip user=new vip(userid,null,null,null,null);
		    request.setAttribute("user", user);
		    List<salemessage> members=service.searchMySalemessage(userid);
			request.setAttribute("mysalemessage", members);
			
			List<salemessage> allmember=service.searchAllSalemessageByConditions(conditions);
			request.setAttribute("allsalemessage", allmember);
		request.getRequestDispatcher("/WEB-INF/views/salemessage/salemessage.jsp").forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
