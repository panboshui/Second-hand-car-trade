package mvc.controler;

import java.io.IOException;
import java.lang.reflect.Method;

import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.bean.manage;
import mvc.bean.vip;
import mvc.service.ManageService;
import mvc.service.VipService;



public class ManageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ManageService service;
    
    public ManageServlet() {
        super();
        this.service=new ManageService();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String servletPath=request.getServletPath();
        System.out.println(servletPath);
        String methodName=servletPath.substring(1, servletPath.length()-3);
        System.out.println(methodName);
        try {
			Method method=getClass().getDeclaredMethod(methodName, HttpServletRequest.class,
					HttpServletResponse.class);
			method.invoke(this, request,response);
		} catch (Exception e) {
			
			e.printStackTrace();
		} 
				
	}
	
	public void searchManage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String message="";
		boolean result=service.searchName(name);
		if(result)
		{
			manage conditions=new manage(null,name,password);
			manage real=service.SearchManageByName(conditions);
			if(real.getPassword().equals(password)) {
				
				 request.setAttribute("manage",real);
				
				 request.getRequestDispatcher("/WEB-INF/views/manage/managepage.jsp").forward(request, response);
			}
			else
			{
				message="�������";
				request.setAttribute("HandleMessage",message);
				request.getRequestDispatcher("/WEB-INF/views/manage/fail.jsp").forward(request, response);
			}
		}
		else
		{
			 message="���û���δע��";
			 request.setAttribute("HandleMessage",message);
			 request.getRequestDispatcher("/WEB-INF/views/manage/fail.jsp").forward(request, response);
		}
	    
	}
	public void returnManagePage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		
				
				 request.getRequestDispatcher("/WEB-INF/views/manage/managepage.jsp").forward(request, response);
		
	    
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
