package mvc.controler;

import java.io.IOException;
import java.lang.reflect.Method;

import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.bean.salemessage;
import mvc.bean.vip;
import mvc.service.VipService;


@WebServlet("*.do" )
public class VipServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private VipService service;
    
    public VipServlet() {
        super();
        this.service=new VipService();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String servletPath=request.getServletPath();
        System.out.println(servletPath);
        String methodName=servletPath.substring(1, servletPath.length()-3);
        System.out.println(methodName);
        try {
			Method method=getClass().getDeclaredMethod(methodName, HttpServletRequest.class,
					HttpServletResponse.class);
			method.invoke(this, request,response);
		} catch (Exception e) {
			
			e.printStackTrace();
		} 
				
	}
	
	public void searchVip(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String message="";
		boolean result=service.searchName(name);
		if(result)
		{
			vip conditions=new vip(null,name,null,null,password);
			vip real=service.SearchVipByName(conditions);
			if(real.getPassword().equals(password)) {
				
				 request.setAttribute("vip",real);
				
				 request.getRequestDispatcher("/WEB-INF/views/vip/vippage.jsp").forward(request, response);
			}
			else
			{
				message="�������";
				request.setAttribute("HandleMessage",message);
				request.getRequestDispatcher("/WEB-INF/views/vip/fail.jsp").forward(request, response);
			}
		}
		else
		{
			 message="���û���δע��";
			 request.setAttribute("HandleMessage",message);
			 request.getRequestDispatcher("/WEB-INF/views/vip/fail.jsp").forward(request, response);
		}
	    
	}
	public void returnToVippage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		
		int id=Integer.parseInt(request.getParameter("id"));
		vip member=service.getVip(id);
	
			
				
		 request.setAttribute("vip",member);
				
	     request.getRequestDispatcher("/WEB-INF/views/vip/vippage.jsp").forward(request, response);
		
	    
	}
	public void editVip(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		vip member=service.getVip(id);
		request.setAttribute("vip", member);
		request.getRequestDispatcher("/WEB-INF/views/vip/vipUpdate.jsp").forward(request, response);
		
	}
	public void deleteVip(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		
		service.deleteVip(id);
		List<vip> allmember=service.searchAllVip();
		request.setAttribute("allvip", allmember);
		request.getRequestDispatcher("/WEB-INF/views/manage/managevip.jsp").forward(request, response);
		
	}
	public void inputMySalemessage(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		vip member=service.getVip(id);
		request.setAttribute("user", member);
		request.getRequestDispatcher("/WEB-INF/views/salemessage/inputsalemessage.jsp").forward(request, response);
		
	}
	public void updateVip(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		String sex=request.getParameter("sex");
		int age=Integer.parseInt(request.getParameter("age"));
		String password=request.getParameter("password");
		vip member=new vip(id,name,sex,age,password);
		boolean result=service.updateVip(member);
		if(result) {
			request.setAttribute("vip",member);
			request.getRequestDispatcher("/WEB-INF/views/vip/vippage.jsp").forward(request, response);
			
		}
		else
		{
			String message="Insert Fail! Please use another Name";
	    	request.setAttribute("ERRORMESSAGE", message);
	    	vip membe=service.getVip(id);
			request.setAttribute("vip", membe);
	    	request.getRequestDispatcher("/WEB-INF/views/vip/vipUpdate.jsp").forward(request, response);
		}
		
	}
	
	public void addVip(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		String name=request.getParameter("name");
		String password=request.getParameter("password");
	    String sex=request.getParameter("sex");
	    int age=Integer.parseInt(request.getParameter("age"));
	 
		vip member=new vip(null,name,sex,age,password);
	    boolean result=service.addVip(member);
	    if(result) {
	    	
	    	request.getRequestDispatcher("viplogin.jsp").forward(request, response);
	    	
	    }else {
	    	String message="Insert Fail! Please use another Name";
	    	request.setAttribute("ERRORMESSAGE", message);
	    	request.getRequestDispatcher("/WEB-INF/views/vip/vipregister.jsp").forward(request, response);
	    }
	}
	
public void listRegister(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		
		
		request.getRequestDispatcher("/WEB-INF/views/vip/vipregister.jsp").forward(request, response);
	}
public void manageVip(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
	
	List<vip> allmember=service.searchAllVip();
	request.setAttribute("allvip", allmember);
	request.getRequestDispatcher("/WEB-INF/views/manage/managevip.jsp").forward(request, response);
}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
