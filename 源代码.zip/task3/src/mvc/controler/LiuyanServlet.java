 package mvc.controler;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.bean.liuyan;
import mvc.bean.salemessage;
import mvc.bean.salemessageSearch;
import mvc.bean.vip;
import mvc.service.LiuyanService;
import mvc.service.SalemessageService;




public class LiuyanServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LiuyanService service;
   
    public LiuyanServlet() {
        super();
        this.service=new LiuyanService();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String servletPath=request.getServletPath();
        System.out.println(servletPath);
        String methodName=servletPath.substring(1, servletPath.length()-3);
        System.out.println(methodName);
        try {
			Method method=getClass().getDeclaredMethod(methodName, HttpServletRequest.class,
					HttpServletResponse.class);
			method.invoke(this, request,response);
		} catch (Exception e) {
			
			e.printStackTrace();
		} 
				
	}
	
	public void searchLiuyan(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));		
		int userid=Integer.parseInt(request.getParameter("userid"));	
		List<liuyan> members=service.searchLiuyan(id);
		request.setAttribute("liuyans", members);
		request.setAttribute("messageid", id);
		request.setAttribute("userid", userid);
		request.getRequestDispatcher("/WEB-INF/views/liuyan/liuyan.jsp").forward(request, response);
	}
	
	public void editLiuyan(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int id=Integer.parseInt(request.getParameter("id"));	
		int userid=Integer.parseInt(request.getParameter("userid"));
		request.setAttribute("messageid", id);
		request.setAttribute("userid", userid);
		request.getRequestDispatcher("/WEB-INF/views/liuyan/inputliuyan.jsp").forward(request, response);
	}
	
	public void inputLiuyan(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		int messageid=Integer.parseInt(request.getParameter("messageid"));	
		int userid=Integer.parseInt(request.getParameter("userid"));
		String content=request.getParameter("content");
		liuyan member=new liuyan(null,content,messageid);
		service.inputLiuyan(member);
		List<liuyan> members=service.searchLiuyan(messageid);
		request.setAttribute("messageid", messageid);
		request.setAttribute("liuyans", members);
		request.setAttribute("userid", userid);
		request.getRequestDispatcher("/WEB-INF/views/liuyan/liuyan.jsp").forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
