package mvc.daoImpl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

import mvc.bean.liuyan;
import mvc.bean.salemessage;
import mvc.bean.salemessageSearch;
import mvc.dao.LiuyanDao;
import mvc.dao.SalemessageDao;


public class LiuyanDaoJdbcImpl extends DAOJdbcImpl<liuyan> implements LiuyanDao {
    

public List<liuyan> searchliuyan(Connection connection, Integer id) throws SQLException {
	String sql="select id,content,messageid from liuyan where messageid=?";
	return fetchList(connection,sql,id);
}

@Override
public void addLiuyan(Connection connection, liuyan member) throws SQLException {
	String sql="insert into liuyan(content,messageid) values(?,?)";
	Object[] objs= {member.getContent(),member.getMessageid()};
	update(connection, sql, objs);
	
}


}
