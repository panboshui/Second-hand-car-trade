package mvc.daoImpl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import mvc.bean.manage;
import mvc.bean.vip;
import mvc.dao.ManageDao;
import mvc.dao.VipDao;

public class ManageDaoJdbcImpl extends DAOJdbcImpl<manage> implements ManageDao {
    
	
	



	@Override
	public manage searchManageByName(Connection connection, manage conditions) throws SQLException {
		
		String sql="select id,name,password from manage where name = ?";
		Object[] objs= {conditions.getName()};
		return fetch(connection,sql,objs);
	}
	
public manage searchName(Connection connection, String name) throws SQLException {
		
		String sql="select name from manage where name = ?";
		Object[] objs= {name};
		return fetch(connection,sql,objs);
	}


}
