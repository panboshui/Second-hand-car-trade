package mvc.daoImpl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

import mvc.bean.salemessage;
import mvc.bean.salemessageSearch;
import mvc.dao.SalemessageDao;


public class SalemessageDaoJdbcImpl extends DAOJdbcImpl<salemessage> implements SalemessageDao {
    

public List<salemessage> searchSaleMessageByUserid(Connection connection, Integer userid) throws SQLException {
	String sql="select id,content,userid,publishflag,messageflag,commitflag from salemessage where userid=?";

	return fetchList(connection,sql,userid);
}

@Override
public void addSalemessage(Connection connection, salemessage member) throws SQLException {
	String sql="insert into salemessage(content,userid) values(?,?)";
	Object[] objs= {member.getContent(),member.getUserid()};
	update(connection, sql, objs);
	
}

@Override
public salemessage searchSalemessageByContent(Connection connection, String content) throws SQLException {
	// TODO Auto-generated method stub
	return null;
}

@Override
public salemessage searchSalemessageById(Connection connection, Integer id) throws SQLException {
	String sql="select id,content,userid,publishflag,messageflag,commitflag from salemessage where id=?";
	return fetch(connection,sql,id);
}

@Override
public void publishSalemessage(Connection connection, salemessage member) throws SQLException {
	String sql="update salemessage set commitflag=? where id=?";
	Object[] objs= {1,member.getId()};
    update(connection,sql,objs);
	
}

@Override
public void updateSalemessage(Connection connection, salemessage member) throws SQLException {
	String sql="update salemessage set content=? where id=?";
	Object[] objs= {member.getContent(),member.getId()};
    update(connection,sql,objs);
	
}
@Override
public List<salemessage> searchAllSaleMessage(Connection connection) throws SQLException {
	String sql="select id,content,userid,publishflag,messageflag,commitflag from salemessage";
	return fetchList(connection,sql);
}

@Override
public void changemessageflag(Connection connection, salemessage member) throws SQLException {
	String sql="update salemessage set messageflag=? where id=?";
	
	
	if(Integer.parseInt(member.getMessageflag())==1)
	{
		Object[] objs1= {0,member.getId()};
		 update(connection,sql,objs1);
	}
	else
	{	
		Object[] objs2= {1,member.getId()};
		 update(connection,sql,objs2);
	
	}	
}

@Override
public void deletemessage(Connection connection, salemessage member) throws SQLException {
	String sql="delete from salemessage where id=?";
	Object[] objs= {member.getId()};
	update(connection,sql,objs);
	
}

@Override
public List<salemessage> searchMySalemessageByCondition(Connection connection,salemessageSearch member) throws SQLException {
	String sql="select id,content,userid,publishflag,messageflag,commitflag from salemessage where content like ? and userid=?";
	Object[] objs= {member.getContent(),member.getId()};
	return fetchList(connection,sql,objs);
}

@Override
public List<salemessage> searchAllSaleMessageByCondition(Connection connection,salemessageSearch member) throws SQLException {
	String sql="select id,content,userid,publishflag,messageflag,commitflag from salemessage where content like ?";
	Object[] objs= {member.getContent()};
	return fetchList(connection,sql,objs);
}

@Override
public List<salemessage> searchCommitSaleMessage(Connection connection) throws SQLException {
	String sql="select id,content,userid,publishflag,messageflag,commitflag from salemessage where commitflag=1 and publishflag=0";
	return fetchList(connection,sql);
}

@Override
public void agreetopublish(Connection connection, Integer id) throws SQLException {
	String sql="update salemessage set publishflag=? where id=?";
	Object[] objs= {1,id};
    update(connection,sql,objs);
	
}

}
