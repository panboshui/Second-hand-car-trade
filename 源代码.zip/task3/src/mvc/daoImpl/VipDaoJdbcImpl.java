package mvc.daoImpl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import mvc.bean.vip;
import mvc.dao.VipDao;

public class VipDaoJdbcImpl extends DAOJdbcImpl<vip> implements VipDao {
    
	
	public void addVip(Connection connection, vip member) throws SQLException {
		String sql="insert into vip(name,sex,age,password) values(?,?,?,?)";
		Object[] objs= {member.getName(),member.getSex(),member.getAge(),member.getPassword()};
		update(connection, sql, objs);
	}



	@Override
	public vip searchVipByName(Connection connection, vip conditions) throws SQLException {
		
		String sql="select id,name,sex,age,password from vip where name = ?";
		Object[] objs= {conditions.getName()};
		return fetch(connection,sql,objs);
	}
	
public vip searchName(Connection connection, String name) throws SQLException {
		
		String sql="select name from vip where name = ?";
		Object[] objs= {name};
		return fetch(connection,sql,objs);
	}




public vip searchVipById(Connection connection, int id) throws SQLException {
	String sql="select id,name,sex,age,password from vip where id = ?";
	return fetch(connection,sql,id);
}

public void updateVip(Connection connection, vip member) throws SQLException {
	String sql="update vip set name=?,sex=?,age=? where id=?";
	Object[] objs= {member.getName(),member.getSex(),member.getAge(),member.getId()};
    update(connection,sql,objs);

	}



@Override
public List<vip> searchAllVip(Connection connection) throws SQLException {
	String sql="select id,name,sex,age,password from vip ";
	return fetchList(connection,sql);
}



@Override
public void deleteVip(Connection connection, Integer id) throws SQLException {
	String sql1="delete from liuyan where messageid in(select id from salemessage where userid=?);";
	update(connection,sql1,id);
	
	
	String sql0="delete from salemessage where userid=?";
	update(connection,sql0,id);
	
	
	String sql="delete from vip where id=?";
	update(connection,sql,id);
	
}



}
